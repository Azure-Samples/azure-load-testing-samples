package tdg;

public class test {
    public static void main(String[] args) {
        System.out.println(generalfun.generate_int_randomnumber());

    }
}
